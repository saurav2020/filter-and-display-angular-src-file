import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {myinterface} from 'src/app/myservice1';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Myservice1Service {
  private _url:string='./assets/booklist.json'

  constructor(private http:HttpClient) { }
  getp():Observable<myinterface[]>
  {
    return this.http.get<myinterface[]>(this._url);
  }
}
