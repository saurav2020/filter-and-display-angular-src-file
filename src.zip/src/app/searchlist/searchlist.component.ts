import { Component, OnInit } from '@angular/core';
import { Myservice1Service } from '../myservice1.service';


@Component({
  selector: 'app-searchlist',
  templateUrl: './searchlist.component.html',
  styleUrls: ['./searchlist.component.css']
})
export class SearchlistComponent implements OnInit {

 
  //jsonString;

  constructor(private _x:Myservice1Service) { }
  public booklist=[];
  ngOnInit() {
    this._x.getp()
    .subscribe(data =>{this.booklist=data})
  }
  delete(i)
  {
    
      this.booklist.splice(i,1);
      }
    
}
