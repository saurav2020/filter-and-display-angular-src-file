import { TestBed } from '@angular/core/testing';

import { Myservice1Service } from './myservice1.service';

describe('Myservice1Service', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Myservice1Service = TestBed.get(Myservice1Service);
    expect(service).toBeTruthy();
  });
});
