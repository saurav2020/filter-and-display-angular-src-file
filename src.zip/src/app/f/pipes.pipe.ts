import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipes'
})
export class PipesPipe implements PipeTransform {

  transform(booklist: any, search: any): any {

 
  if(search == undefined)
  return ;
  
  return booklist.filter(function(booklist:any){
    return booklist.author.toLowerCase().includes(search.toString().toLowerCase()) || booklist.title.toLowerCase().includes(search.toString().toLowerCase()) || booklist.id.toString().includes(search);
  });

  }

}
