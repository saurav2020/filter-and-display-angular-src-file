import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookdetailsComponent } from './bookdetails/bookdetails.component';
import {HttpClientModule} from '@angular/common/http';
import { PipesPipe } from './f/pipes.pipe';
import { SearchlistComponent } from './searchlist/searchlist.component';
// import {Myservice1Service} from 'src/app/myservice1.service';
import {FormsModule} from '@angular/forms'


@NgModule({
  declarations: [
    AppComponent,
    BookdetailsComponent,
    PipesPipe,
    SearchlistComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    //Myservice1Service


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
