import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookdetailsComponent } from './bookdetails/bookdetails.component';
import { SearchlistComponent } from './searchlist/searchlist.component';


const routes: Routes = [{ path: '', redirectTo: '/bookdetails', pathMatch: 'full' }, { path: 'bookdetails', component: BookdetailsComponent }, { path: 'searchlist', component: SearchlistComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
