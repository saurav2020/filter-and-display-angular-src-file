import { Component, OnInit } from '@angular/core';
import { Myservice1Service } from '../myservice1.service';

@Component({
  selector: 'app-bookdetails',
  templateUrl: './bookdetails.component.html',
  styleUrls: ['./bookdetails.component.css']
})
export class BookdetailsComponent implements OnInit {
  public booklist=[];
  //jsonString;

  constructor(private _x:Myservice1Service) { }

  show()
  {
    this._x.getp()
    .subscribe(data =>{this.booklist=data})
  }
  ngOnInit() {
    
  }
  
 

}
